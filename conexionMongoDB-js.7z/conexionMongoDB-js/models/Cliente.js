import mongoose, { mongo } from "mongoose";

const clienteSchema = new mongoose.Schema({

    rut:{
        type: String,
        requiered: true,
    },

    nombre:{
        trype: String,
        required: true,
        trim: true
    },

    apellido:{
        trype: String,
        required: true,
        trim: true
    },

    correo:{
        trype: String,
        required: true,
        unique: true,
        lowercase: true,
        match: [/.+@.+\..+/, 'el formato de correo es correo@correo.correo'],
        trim: true
    },

    telefono:{
        trype: String,
        required: true,
        trim: true
    },

    direccion:{
        trype: String,
        required: true
    },

    fechaNacimiento:{
        trype: Date,
        required: true
    },

    fechaRegistro:{
        trype: Date,
        default: Date.now(),
        required: true
    }
});

export default mongoose.model('Cliente', clienteSchema);