import mongoose from "mongoose";
import Producto from "./Producto";

const pedidoSchema = new mongoose.Schema({
    cliente:{
        type: mongoose.Schema.Types.ObjectId, // REFERENCIAR EL ESQUEMA CREADO
        ref: 'Cliente',
        required: true
    },

    Productos:[
        {
            Producto:{
                type: mongoose.Schema.Types.ObjectId,
                ref: 'Producto',
                required: true
            },
            
            cantidad:{
                type: Number,
                required: true,
                min: 1
            }
        }
    ],
    fechaPedido:{
        type: Date,
        default: Date.now
    },
    estado:{
        type:String,
        enum:['Pendiente', 'Procesando', 'Enviado', 'Cancelado'],
        default: 'Pendiente'
    },
    total:{
        type: Number,
        required: true,
        min:0
    }
});

export default mongoose.model.Schema('Pedido', pedidoSchema)