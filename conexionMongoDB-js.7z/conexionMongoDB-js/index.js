import dotenv from 'dotenv';

dotenv.config();
import express from 'express'; //servidor web
import mongoose from 'mongoose'; //conexion Mongodb
const app = express();
const PORT = process.env.PORT // || 3000; inceseario indicar el puerto ya esta configurado en .env

mongoose.connect(process.env.MONGO_URI) //uri se encuentra en el .env
    .then(()=>{console.log('Connect MongoDB');
    })
    .catch((error)=>{
        console.log('no connect mongoDB Error: ', error);
        process.exit(1);
    });

app.listen(PORT, ()=>{
    console.log(`server started  Port: ${PORT}`);
});
app.get('/', (req, res)=>{  // res enseña req recibe
    res.send('<h1>hello world<h1/>'); // lo que se enseña en la pagina 
})